﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Web.Http;

namespace GameStoreSelfHost
{
   public class GameStoreController : ApiController
    {
        public List<string> GetCatergorys()
        {
            DataTable lcResult = clsDbConnection.GetDataTable("SELECT name FROM catergorys", null);
            List<string> lcNames = new List<string>();
            foreach (DataRow dr in lcResult.Rows)
                lcNames.Add((string)dr[0]);
            return lcNames;
        }

        public List<clsGame> GetGames()
        {
            DataTable lcResult = clsDbConnection.GetDataTable("SELECT * FROM game", null);
            List<clsGame> lcNames = new List<clsGame>();
            clsGame lcGame;
            foreach (DataRow dr in lcResult.Rows)
            {
                lcGame = new clsGame();
                lcGame.name = dr["name"].ToString();
                lcGame.rating = dr["rating"].ToString();
                lcGame.digi_or_hard = Convert.ToChar(dr["digi_or_hard"]);
                if (lcGame.digi_or_hard == 'H') lcGame.number_discs = Convert.ToInt16(dr["number_discs"]);
                if (lcGame.digi_or_hard == 'H') lcGame.stock_number = Convert.ToInt16(dr["stock_number"]);
                lcGame.price = Convert.ToDecimal(dr["price"]);
                if (lcGame.digi_or_hard == 'D') lcGame.file_size = Convert.ToInt32(dr["file_size"]);
                if (lcGame.digi_or_hard == 'D') lcGame.download_location = dr["download_location"].ToString();
                lcGame.catergory = dr["catergory"].ToString();
                lcNames.Add(lcGame);
            }
            return lcNames;
        }

        public List<clsOrders> GetOrders()
        {
            DataTable lcResult = clsDbConnection.GetDataTable("SELECT * FROM orders", null);
            List<clsOrders> lcNames = new List<clsOrders>();
            foreach (DataRow dr in lcResult.Rows)
                lcNames.Add(dataRow2Order(dr));
            return lcNames;
        }


        public clsGame GetGame(string Name,string Digi_or_Hard)
        {
            Dictionary<string, object> par = new Dictionary<string, object>(1);
            par.Add("name", Name);
            par.Add("digi_or_hard", Digi_or_Hard);
            DataTable lcResult =
        clsDbConnection.GetDataTable("SELECT * FROM game WHERE name = @Name AND digi_or_hard=@Digi_or_Hard", par);
            if (lcResult.Rows.Count > 0)
            {
                clsGame lcGame = new clsGame();
                lcGame.name = lcResult.Rows[0]["name"].ToString();
                lcGame.rating = lcResult.Rows[0]["rating"].ToString();
                string lcNumDisc = lcResult.Rows[0]["number_discs"].ToString();
                string lcStock = lcResult.Rows[0]["stock_number"].ToString();
                if (lcNumDisc != "") lcGame.number_discs = Convert.ToInt16(lcResult.Rows[0]["number_discs"]);
                if (lcStock != "") lcGame.stock_number = Convert.ToInt16(lcResult.Rows[0]["stock_number"]);//getArtistsWork(Name)
                lcGame.price = Convert.ToDecimal(lcResult.Rows[0]["price"]);
                string lcFileSize = lcResult.Rows[0]["file_size"].ToString();
                if (lcFileSize != "") lcGame.file_size = Convert.ToInt32(lcFileSize);
                if (lcResult.Rows[0]["download_location"] != null) lcGame.download_location = lcResult.Rows[0]["download_location"].ToString();
                lcGame.digi_or_hard = Convert.ToChar(lcResult.Rows[0]["digi_or_hard"]);
                lcGame.catergory = lcResult.Rows[0]["catergory"].ToString();
                return lcGame;
            }
            else
                return null;
        }

        private clsOrders GetOrder(int ID)
        {
            Dictionary<string, object> par = new Dictionary<string, object>(1);
            par.Add("id", ID);
            DataTable lcResult = clsDbConnection.GetDataTable("SELECT * FROM orders WHERE id=@ID", par);
            if (lcResult.Rows.Count > 0)
            {
                return dataRow2Order(lcResult.Rows[0]);
            }
            return null;

        }

        private clsOrders dataRow2Order(DataRow prDataRow)
        {
            return new clsOrders()
            {
                id = Convert.ToInt16(prDataRow["id"]),
                game_name = Convert.ToString(prDataRow["game_name"]),
                total_price = Convert.ToDecimal(prDataRow["total_price"]),
                customer_name = Convert.ToString(prDataRow["customer_name"]),
                customer_email = Convert.ToString(prDataRow["customer_email"]),
                customer_address = Convert.ToString(prDataRow["customer_address"]),
                sale_date = Convert.ToDateTime(prDataRow["sale_date"]),
                quantity = Convert.ToInt16(prDataRow["quantity"]),
            };

        }

        public string PutGame(clsGame prGame)
        {   // update
            try
            {
                int lcRecCount = clsDbConnection.Execute(
        "UPDATE game SET rating = @rating, price = @price,number_discs=@number_discs,stock_number=@stock_number,file_size=@file_size,download_location=@download_location,digi_or_hard=@digi_or_hard,catergory=@catergory WHERE name=@name",
        prepareGameParameters(prGame));
                if (lcRecCount == 1)
                    return "One game updated";
                else
                    return "Unexpected game update count: " + lcRecCount;
            }
            catch (Exception ex)
            {
                return ex.GetBaseException().Message;
            }
        }
        
        public string DeleteGame(string GameName, string digihard)
        {   // delete
            try
            {
                int lcRecCount = clsDbConnection.Execute(
        "DELETE FROM game WHERE name='" + GameName + "' AND digi_or_hard='" + digihard + "'",null);
                if (lcRecCount == 1)
                    return "One game deleted";
                else
                    return "Unexpected game delete count: " + lcRecCount;
            }
            catch (Exception ex)
            {
                return ex.GetBaseException().Message;
            }
        }

        public string DeleteOrder(int prID)
        {   // delete
            try
            {
                int lcRecCount = clsDbConnection.Execute(
                    "DELETE FROM orders WHERE id=" + prID.ToString(),null);
                if (lcRecCount == 1)
                    return "One order deleted";
                else
                    return "Unexpected order delete count: " + lcRecCount;
            }
            catch (Exception ex)
            {
                return ex.GetBaseException().Message;
            }
        }

        public string PostGame(clsGame prGame)
        {   // insert
            try
            {
                int lcRecCount = clsDbConnection.Execute(
        "INSERT INTO game VALUES(@name,@rating,@price,@number_discs,@stock_number,@file_size,@download_location,@digi_or_hard,@catergory)",
        prepareGameParameters(prGame));
                if (lcRecCount == 1)
                    return "One game inserted";
                else
                    return "Unexpected game insert count: " + lcRecCount;
            }
            catch (Exception ex)
            {
                return ex.GetBaseException().Message;
            }
        }

        private Dictionary<string, object> prepareGameParameters(clsGame prGame)
        {
            Dictionary<string, object> par = new Dictionary<string, object>(3);
            par.Add("name", prGame.name);
            par.Add("rating", prGame.rating);
            par.Add("number_discs", prGame.number_discs);
            par.Add("stock_number", prGame.stock_number);
            par.Add("price", prGame.price);
            par.Add("file_size", prGame.file_size);
            par.Add("download_location", prGame.download_location);
            par.Add("digi_or_hard", prGame.digi_or_hard);
            par.Add("catergory", prGame.catergory);
            return par;
        }

        public string PutOrder(clsOrders prOrder)
        {   // update
            try
            {
                int lcRecCount = clsDbConnection.Execute("UPDATE orders SET " +
                "game_name = @game_name,total_price=@total_price,customer_name=@customer_name,customer_email=@customer_email," +
                "customer_address=@customer_address,sale_date=@sale_date,quantity=@quantity WHERE id=@id",
                prepareWorkParameters(prOrder));
                if (lcRecCount == 1)
                    return "One order updated";
                else
                    return "Unexpected order update count: " + lcRecCount;
            }
            catch (Exception ex)
            {
                return ex.GetBaseException().Message;
            }
        }

        public string PostOrder(clsOrders prOrder)
        {   // insert
            try
            {
                int lcRecCount = clsDbConnection.Execute("INSERT INTO orders " +
                "(game_name,total_price,customer_name,customer_email,customer_address,sale_date,quantity) " +
                "VALUES (@game_name,@total_price,@customer_name,@customer_email," +
                "@customer_address,@sale_date,@quantity)",
                prepareWorkParameters(prOrder));
                if (lcRecCount == 1)
                    return "One order inserted";
                else
                    return "Unexpected order insert count: " + lcRecCount;
            }
            catch (Exception ex)
            {
                return ex.GetBaseException().Message;
            }
        }

        private Dictionary<string, object> prepareWorkParameters(clsOrders prOrder)
        {
            Dictionary<string, object> par = new Dictionary<string, object>(10);
            par.Add("id", prOrder.id);
            par.Add("game_name", prOrder.game_name);
            par.Add("total_price", prOrder.total_price);
            par.Add("customer_name", prOrder.customer_name);
            par.Add("customer_email", prOrder.customer_email);
            par.Add("customer_address", prOrder.customer_address);
            par.Add("sale_date", prOrder.sale_date);
            par.Add("quantity", prOrder.quantity);
            return par;
        }


    }
}
