﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameStoreSelfHost
{
    public class clsCatergorys
    {
        public string name { get; set; }
        public string describe { get; set; }

    }

    public class clsGame
    {
        public string name { get; set; }
        public string rating { get; set; }
        public int number_discs { get; set; }
        public int stock_number { get; set; }
        public decimal price { get; set; }
        public int file_size { get; set; }
        public string download_location { get; set; }
        public char digi_or_hard { get; set; }
        public string catergory { get; set; }
    }

    public class clsOrders
    {
        public int id { get; set; }
        public string game_name { get; set; }
        public decimal total_price { get; set; }
        public string customer_name { get; set; }
        public string customer_email { get; set; }
        public string customer_address { get; set; }
        public DateTime sale_date { get; set; }
        public int quantity { get; set; }
    }


}
