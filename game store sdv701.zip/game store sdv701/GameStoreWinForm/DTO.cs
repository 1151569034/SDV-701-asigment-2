﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameStoreWinForm
{
    public class clsCatergorys
    {
        public string name { get; set; }
        public string describe { get; set; }

    }

    public class clsGame
    {
        public string name { get; set; }
        public string rating { get; set; }
        public int number_discs { get; set; }
        public int stock_number { get; set; }
        public decimal price { get; set; }
        public int file_size { get; set; }
        public string download_location { get; set; }
        public char digi_or_hard { get; set; }
        public string catergory { get; set; }

        public override string ToString()
        {
            return name + "\t" + Convert.ToString(digi_or_hard);
        }

        public static readonly string FACTORY_PROMPT = "Enter H for Hard Copy, or D for Digital?";

        public static clsGame NewWork(char prChoice)
        {
            return new clsGame() { digi_or_hard = Char.ToUpper(prChoice) };
        }
    }

    public class clsOrders
    {
        public int id { get; set; }
        public string game_name { get; set; }
        public decimal total_price { get; set; }
        public string customer_name { get; set; }
        public string customer_email { get; set; }
        public string customer_address { get; set; }
        public DateTime sale_date { get; set; }
        public int quantity { get; set; }

        public override string ToString()
        {
            return id.ToString() + "\t" + Convert.ToString(customer_name) + "\t" + Convert.ToString(game_name);
        }

    }

}
