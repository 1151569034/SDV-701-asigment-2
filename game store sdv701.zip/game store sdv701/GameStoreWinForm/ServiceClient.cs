﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using Newtonsoft.Json;

namespace GameStoreWinForm
{
    public static class ServiceClient
    {
        internal async static Task<List<string>> GetCatergorysAsync()
        {
            using (HttpClient lcHttpClient = new HttpClient())
                return JsonConvert.DeserializeObject<List<string>>
            (await lcHttpClient.GetStringAsync("http://localhost:60064/api/gamestore/GetCatergorys/"));
        }

        internal async static Task<List<clsGame>> GetGamesAsync()
        {
            using (HttpClient lcHttpClient = new HttpClient())
                return JsonConvert.DeserializeObject<List<clsGame>>
            (await lcHttpClient.GetStringAsync("http://localhost:60064/api/gamestore/GetGames/"));
        }

        internal async static Task<List<clsOrders>> GetOrdersAsync()
        {
            using (HttpClient lcHttpClient = new HttpClient())
                return JsonConvert.DeserializeObject<List<clsOrders>>
            (await lcHttpClient.GetStringAsync("http://localhost:60064/api/gamestore/GetOrders/"));
        }

        private async static Task<string> InsertOrUpdateAsync<TItem>(TItem prItem, string prUrl, string prRequest)
        {
            using (HttpRequestMessage lcReqMessage = new HttpRequestMessage(new HttpMethod(prRequest), prUrl))
            using (lcReqMessage.Content =
        new StringContent(JsonConvert.SerializeObject(prItem), Encoding.Default, "application/json"))
            using (HttpClient lcHttpClient = new HttpClient())
            {
                HttpResponseMessage lcRespMessage = await lcHttpClient.SendAsync(lcReqMessage);
                return await lcRespMessage.Content.ReadAsStringAsync();
            }
        }

        internal async static Task<string> UpdateOrderAsync(clsOrders _Order)
        {
            return await InsertOrUpdateAsync(_Order, "http://localhost:60064/api/gamestore/PutOrder", "PUT");
        }

        internal async static Task<string> InsertOrderAsync(clsOrders _Order)
        {
            return await InsertOrUpdateAsync(_Order, "http://localhost:60064/api/gamestore/PostOrder", "POST");
        }

        internal async static Task<string> InsertGameAsync(clsGame prGame)
        {
            return await InsertOrUpdateAsync(prGame, "http://localhost:60064/api/gamestore/PostGame", "POST");
        }

        internal async static Task<string> UpdateGameAsync(clsGame prGame)
        {
            return await InsertOrUpdateAsync(prGame, "http://localhost:60064/api/gamestore/PutGame", "PUT");
        }

        internal async static Task<string> DeleteOrderAsync(clsOrders prOrder)
        {
            using (HttpClient lcHttpClient = new HttpClient())
            {
                HttpResponseMessage lcRespMessage = await lcHttpClient.DeleteAsync
            ($"http://localhost:60064/api/gamestore/DeleteOrder?prID={prOrder.id}");
                return await lcRespMessage.Content.ReadAsStringAsync();
            }

        }

        internal async static Task<string> DeleteGameAsync(string prName, char prDigiHard)
        {
            using (HttpClient lcHttpClient = new HttpClient())
            {
                HttpResponseMessage lcRespMessage = await lcHttpClient.DeleteAsync
            ($"http://localhost:60064/api/gamestore/DeleteGame?GameName={prName}&digihard={prDigiHard}");
                return await lcRespMessage.Content.ReadAsStringAsync();
            }
            throw new NotImplementedException();
        }
    }
}
