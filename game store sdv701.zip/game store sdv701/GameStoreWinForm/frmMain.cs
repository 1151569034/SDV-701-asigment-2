using System;
using System.Windows.Forms;

namespace GameStoreWinForm

{
    public sealed partial class frmMain : Form
    {   //Singleton
        private static readonly frmMain _Instance = new frmMain();

        public delegate void Notify(string prStoreName);

        public event Notify StoreNameChanged;

        private frmMain()
        {
            InitializeComponent();
        }

        public static frmMain Instance
        {
            get { return frmMain._Instance; }
        }

        private void updateTitle(string prStoreName)
        {
            if (!string.IsNullOrEmpty(prStoreName))
                Text = "Business App - " + prStoreName;
        }

        public async void UpdateDisplay()
        {
            lstGames.DataSource = null;
            lstGames.DataSource = await ServiceClient.GetGamesAsync();
            lstOrders.DataSource = null;
            lstOrders.DataSource = await ServiceClient.GetOrdersAsync();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string lcReply = new InputBox(clsGame.FACTORY_PROMPT).Answer;
            if (!string.IsNullOrEmpty(lcReply))
            {
                clsGame lcGame = clsGame.NewWork(lcReply[0]);
                if (lcGame != null) 
                {
                    frmGame.DispatchWorkForm(lcGame);
                    frmMain.Instance.UpdateDisplay();
                }
            }
        }

        private void lstGames_DoubleClick(object sender, EventArgs e)
        {
            try
            {
                frmGame.DispatchWorkForm(lstGames.SelectedItem as clsGame);
                frmMain.Instance.UpdateDisplay();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private async void btnDelete_Click(object sender, EventArgs e)
        {
            clsGame lcKey;

            lcKey = (clsGame)lstGames.SelectedItem;
            if (lcKey != null && MessageBox.Show("Are you sure?", "Deleting Game", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                try
                {
                    MessageBox.Show(await ServiceClient.DeleteGameAsync(lcKey.name,lcKey.digi_or_hard));
                    lstGames.ClearSelected();
                    frmMain.Instance.UpdateDisplay();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error deleting game");
                }
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            UpdateDisplay();
            StoreNameChanged += new Notify(updateTitle);
            StoreNameChanged("Game Store");
            updateTitle("Game Store");
        }

        private void btnGalName_Click(object sender, EventArgs e)
        {
            string lcName = new InputBox("Enter Store Name:").Answer;
            StoreNameChanged(lcName);
        }

        private async void btnDeleteOrder_Click(object sender, EventArgs e)
        {
            clsOrders lcKey;

            lcKey = (clsOrders)lstOrders.SelectedItem;
            if (lcKey != null && MessageBox.Show("Are you sure?", "Deleting Order", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                try
                {
                    MessageBox.Show(await ServiceClient.DeleteOrderAsync(lcKey));
                    lstOrders.ClearSelected();
                    frmMain.Instance.UpdateDisplay();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error deleting Order");
                }
        }

        private void lstOrders_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (lstOrders.Items.Count > 0)
                {
                    clsOrders lcOrder = (clsOrders)lstOrders.SelectedItem;
                    lblOrderDetails.Text = "Order Details:\nID: " + lcOrder.id.ToString() +
                        "\nName: " + lcOrder.customer_name +
                        "\nAddress: " + lcOrder.customer_address +
                        "\nEmail: " + lcOrder.customer_email +
                        "\nGame: " + lcOrder.game_name +
                        "\nQuantity: " + lcOrder.quantity.ToString() +
                        "\nDate: " + lcOrder.sale_date.ToString() +
                        "\nCost: " + lcOrder.total_price.ToString();
                }
            }
            catch (Exception ex) { }
        }

        private void btnRefresh2_Click(object sender, EventArgs e)
        {
            frmMain.Instance.UpdateDisplay();
        }

        private void btnRefresh1_Click(object sender, EventArgs e)
        {
            frmMain.Instance.UpdateDisplay();
        }
    }
}