namespace GameStoreWinForm
{
    public sealed partial class frmDigital : GameStoreWinForm.frmGame
    {   //Singleton
        public static readonly frmDigital Instance = new frmDigital();

        private frmDigital()
        {
            InitializeComponent();
        }

        public static void Run(clsGame prGame)
        {
            Instance.SetDetails(prGame);
        }

        protected override void updateForm()
        {
            base.updateForm();
            txtSize.Text = _Game.file_size.ToString();
            txtLocation.Text = _Game.download_location;
        }

        protected override void pushData()
        {
            base.pushData();
            _Game.file_size = int.Parse(txtSize.Text);
            _Game.download_location = txtLocation.Text;
            _Game.stock_number = 0;
            _Game.number_discs = 0;
        }
    }
}

