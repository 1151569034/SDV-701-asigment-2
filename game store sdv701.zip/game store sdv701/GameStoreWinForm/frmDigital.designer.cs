namespace GameStoreWinForm
{
    partial class frmDigital
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtLocation = new System.Windows.Forms.TextBox();
            this.Label5 = new System.Windows.Forms.Label();
            this.txtSize = new System.Windows.Forms.TextBox();
            this.Label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtLocation
            // 
            this.txtLocation.Location = new System.Drawing.Point(97, 155);
            this.txtLocation.Name = "txtLocation";
            this.txtLocation.Size = new System.Drawing.Size(243, 21);
            this.txtLocation.TabIndex = 5;
            // 
            // Label5
            // 
            this.Label5.Location = new System.Drawing.Point(9, 161);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(80, 15);
            this.Label5.TabIndex = 56;
            this.Label5.Text = "Location";
            // 
            // txtSize
            // 
            this.txtSize.Location = new System.Drawing.Point(97, 128);
            this.txtSize.Name = "txtSize";
            this.txtSize.Size = new System.Drawing.Size(122, 21);
            this.txtSize.TabIndex = 4;
            // 
            // Label4
            // 
            this.Label4.Location = new System.Drawing.Point(9, 135);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(80, 15);
            this.Label4.TabIndex = 54;
            this.Label4.Text = "File Size";
            // 
            // frmDigital
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.ClientSize = new System.Drawing.Size(352, 188);
            this.Controls.Add(this.txtSize);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.Label5);
            this.Controls.Add(this.txtLocation);
            this.Name = "frmDigital";
            this.Text = "Digital";
            this.Controls.SetChildIndex(this.txtLocation, 0);
            this.Controls.SetChildIndex(this.Label5, 0);
            this.Controls.SetChildIndex(this.Label4, 0);
            this.Controls.SetChildIndex(this.txtSize, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.TextBox txtLocation;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.TextBox txtSize;
        internal System.Windows.Forms.Label Label4;
    }
}
