namespace GameStoreWinForm
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblValue = new System.Windows.Forms.Label();
            this.lblOrderDetails = new System.Windows.Forms.Label();
            this.btnQuit = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.Label1 = new System.Windows.Forms.Label();
            this.lstGames = new System.Windows.Forms.ListBox();
            this.btnGalName = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.lstOrders = new System.Windows.Forms.ListBox();
            this.btnDeleteOrder = new System.Windows.Forms.Button();
            this.btnRefresh1 = new System.Windows.Forms.Button();
            this.btnRefresh2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblValue
            // 
            this.lblValue.Location = new System.Drawing.Point(87, 204);
            this.lblValue.Name = "lblValue";
            this.lblValue.Size = new System.Drawing.Size(68, 15);
            this.lblValue.TabIndex = 13;
            // 
            // lblOrderDetails
            // 
            this.lblOrderDetails.Location = new System.Drawing.Point(322, 190);
            this.lblOrderDetails.Name = "lblOrderDetails";
            this.lblOrderDetails.Size = new System.Drawing.Size(270, 154);
            this.lblOrderDetails.TabIndex = 12;
            this.lblOrderDetails.Text = "Order Details:";
            // 
            // btnQuit
            // 
            this.btnQuit.Location = new System.Drawing.Point(598, 315);
            this.btnQuit.Name = "btnQuit";
            this.btnQuit.Size = new System.Drawing.Size(80, 30);
            this.btnQuit.TabIndex = 11;
            this.btnQuit.Text = "Quit";
            this.btnQuit.Click += new System.EventHandler(this.btnQuit_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(227, 62);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(80, 30);
            this.btnDelete.TabIndex = 10;
            this.btnDelete.Text = "Delete";
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(227, 27);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(80, 30);
            this.btnAdd.TabIndex = 9;
            this.btnAdd.Text = "Add";
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // Label1
            // 
            this.Label1.Location = new System.Drawing.Point(17, 12);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(136, 15);
            this.Label1.TabIndex = 8;
            this.Label1.Text = "Games";
            // 
            // lstGames
            // 
            this.lstGames.ItemHeight = 12;
            this.lstGames.Location = new System.Drawing.Point(17, 27);
            this.lstGames.Name = "lstGames";
            this.lstGames.Size = new System.Drawing.Size(204, 316);
            this.lstGames.TabIndex = 7;
            this.lstGames.DoubleClick += new System.EventHandler(this.lstGames_DoubleClick);
            // 
            // btnGalName
            // 
            this.btnGalName.Location = new System.Drawing.Point(598, 278);
            this.btnGalName.Name = "btnGalName";
            this.btnGalName.Size = new System.Drawing.Size(80, 30);
            this.btnGalName.TabIndex = 14;
            this.btnGalName.Text = "Shop Name";
            this.btnGalName.Click += new System.EventHandler(this.btnGalName_Click);
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(322, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(136, 15);
            this.label3.TabIndex = 16;
            this.label3.Text = "Orders";
            // 
            // lstOrders
            // 
            this.lstOrders.ItemHeight = 12;
            this.lstOrders.Location = new System.Drawing.Point(322, 27);
            this.lstOrders.Name = "lstOrders";
            this.lstOrders.Size = new System.Drawing.Size(270, 160);
            this.lstOrders.TabIndex = 15;
            this.lstOrders.SelectedIndexChanged += new System.EventHandler(this.lstOrders_SelectedIndexChanged);
            // 
            // btnDeleteOrder
            // 
            this.btnDeleteOrder.Location = new System.Drawing.Point(598, 27);
            this.btnDeleteOrder.Name = "btnDeleteOrder";
            this.btnDeleteOrder.Size = new System.Drawing.Size(80, 30);
            this.btnDeleteOrder.TabIndex = 18;
            this.btnDeleteOrder.Text = "Delete";
            this.btnDeleteOrder.Click += new System.EventHandler(this.btnDeleteOrder_Click);
            // 
            // btnRefresh1
            // 
            this.btnRefresh1.Location = new System.Drawing.Point(598, 62);
            this.btnRefresh1.Name = "btnRefresh1";
            this.btnRefresh1.Size = new System.Drawing.Size(80, 30);
            this.btnRefresh1.TabIndex = 19;
            this.btnRefresh1.Text = "Refresh";
            this.btnRefresh1.Click += new System.EventHandler(this.btnRefresh1_Click);
            // 
            // btnRefresh2
            // 
            this.btnRefresh2.Location = new System.Drawing.Point(227, 98);
            this.btnRefresh2.Name = "btnRefresh2";
            this.btnRefresh2.Size = new System.Drawing.Size(80, 30);
            this.btnRefresh2.TabIndex = 20;
            this.btnRefresh2.Text = "Refresh";
            this.btnRefresh2.Click += new System.EventHandler(this.btnRefresh2_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(686, 353);
            this.Controls.Add(this.btnRefresh2);
            this.Controls.Add(this.btnRefresh1);
            this.Controls.Add(this.btnDeleteOrder);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lstOrders);
            this.Controls.Add(this.btnGalName);
            this.Controls.Add(this.lblValue);
            this.Controls.Add(this.lblOrderDetails);
            this.Controls.Add(this.btnQuit);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.lstGames);
            this.Name = "frmMain";
            this.Text = "Business App - Game Store";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.Label lblValue;
        internal System.Windows.Forms.Label lblOrderDetails;
        internal System.Windows.Forms.Button btnQuit;
        internal System.Windows.Forms.Button btnDelete;
        internal System.Windows.Forms.Button btnAdd;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.ListBox lstGames;
        internal System.Windows.Forms.Button btnGalName;
        internal System.Windows.Forms.Label label3;
        internal System.Windows.Forms.ListBox lstOrders;
        internal System.Windows.Forms.Button btnDeleteOrder;
        internal System.Windows.Forms.Button btnRefresh1;
        internal System.Windows.Forms.Button btnRefresh2;
    }
}

