namespace GameStoreWinForm
{
    public sealed partial class frmHard : GameStoreWinForm.frmGame
    {   //Singleton
        private static readonly frmHard Instance = new frmHard();

        private frmHard()
        {
            InitializeComponent();
        }

        public static void Run(clsGame prGame)
        {
            Instance.SetDetails(prGame);
        }

        protected override void updateForm()
        {
            base.updateForm();
            txtStock.Text = _Game.stock_number.ToString();
            txtDiscs.Text = _Game.number_discs.ToString();
        }

        protected override void pushData()
        {
            base.pushData();
            _Game.stock_number= int.Parse(txtStock.Text);
            _Game.number_discs = int.Parse(txtDiscs.Text);
            _Game.download_location = "";
            _Game.file_size = 0;
        }

    }
}

