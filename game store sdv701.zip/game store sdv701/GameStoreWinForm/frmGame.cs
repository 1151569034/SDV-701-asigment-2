using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace GameStoreWinForm
{
    public partial class frmGame : Form
    {
        protected clsGame _Game;

        public delegate void LoadGameFormDelegate(clsGame prGame);

        public static Dictionary<char, Delegate> _GamesForm = new Dictionary<char, Delegate>
        {
            {'H', new LoadGameFormDelegate(frmHard.Run)},
            {'D', new LoadGameFormDelegate(frmDigital.Run)}
        };

        public static void DispatchWorkForm(clsGame prGame)
        {
            _GamesForm[prGame.digi_or_hard].DynamicInvoke(prGame);
        }

        public frmGame()
        {
            InitializeComponent();
        }

        public async void SetDetails(clsGame prGame)
        {
            _Game = prGame;
            cbCatergory.DataSource = await ServiceClient.GetCatergorysAsync();
            updateForm();
            ShowDialog();
        }

        private async void btnOK_Click(object sender, EventArgs e)
        {
            if (isValid())
            {
                pushData();
                if (txtName.Enabled)
                    MessageBox.Show(await ServiceClient.InsertGameAsync(_Game));
                else
                    MessageBox.Show(await ServiceClient.UpdateGameAsync(_Game));

                Close();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        protected virtual bool isValid()
        {
            return true;
        }

        protected virtual void updateForm()
        {
            txtName.Text = _Game.name;
            txtName.Enabled = string.IsNullOrEmpty(_Game.name);
            txtRating.Text = _Game.rating;
            cbCatergory.Text = _Game.catergory;
            txtPrice.Text = _Game.price.ToString();
        }

        protected virtual void pushData()
        {
            _Game.name = txtName.Text;
            _Game.rating = txtRating.Text;
            _Game.catergory = cbCatergory.Text;
            _Game.price = decimal.Parse(txtPrice.Text);
        }

    }
}