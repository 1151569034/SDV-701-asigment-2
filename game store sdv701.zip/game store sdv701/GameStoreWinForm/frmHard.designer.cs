namespace GameStoreWinForm
{
    partial class frmHard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtDiscs = new System.Windows.Forms.TextBox();
            this.Label5 = new System.Windows.Forms.Label();
            this.txtStock = new System.Windows.Forms.TextBox();
            this.Label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtDiscs
            // 
            this.txtDiscs.Location = new System.Drawing.Point(97, 155);
            this.txtDiscs.Name = "txtDiscs";
            this.txtDiscs.Size = new System.Drawing.Size(122, 21);
            this.txtDiscs.TabIndex = 5;
            // 
            // Label5
            // 
            this.Label5.Location = new System.Drawing.Point(9, 158);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(56, 21);
            this.Label5.TabIndex = 48;
            this.Label5.Text = "# Discs";
            // 
            // txtStock
            // 
            this.txtStock.Location = new System.Drawing.Point(97, 128);
            this.txtStock.Name = "txtStock";
            this.txtStock.Size = new System.Drawing.Size(122, 21);
            this.txtStock.TabIndex = 4;
            // 
            // Label4
            // 
            this.Label4.Location = new System.Drawing.Point(9, 135);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(56, 21);
            this.Label4.TabIndex = 46;
            this.Label4.Text = "Stock";
            // 
            // frmHard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.ClientSize = new System.Drawing.Size(352, 197);
            this.Controls.Add(this.txtStock);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.Label5);
            this.Controls.Add(this.txtDiscs);
            this.Name = "frmHard";
            this.Text = "Hard Copy";
            this.Controls.SetChildIndex(this.txtDiscs, 0);
            this.Controls.SetChildIndex(this.Label5, 0);
            this.Controls.SetChildIndex(this.Label4, 0);
            this.Controls.SetChildIndex(this.txtStock, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        internal System.Windows.Forms.TextBox txtDiscs;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.TextBox txtStock;
        internal System.Windows.Forms.Label Label4;
    }
}
